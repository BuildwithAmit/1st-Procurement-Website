import { Component } from '@angular/core';

@Component({
  selector: 'app-partnership-card',
  templateUrl: './partnership-card.component.html',
  styleUrls: ['./partnership-card.component.css']
})
export class PartnershipCardComponent {

}
